const express = require('express');
const mongoose = require('mongoose');

const app = express();
const port = 4000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://127.0.0.1:27017/feedbackapp', { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
})
.then(() => console.log(" Connected to MongoDB"))
.catch(err => console.error(" MongoDB connection error:", err));

// Define Schema & Model
const feedbackSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    message: { type: String, required: true },
    rating: { type: Number, min: 1, max: 5, required: true },
    submittedAt: { type: Date, default: Date.now }
});

const Feedback = mongoose.model('Feedback', feedbackSchema);

// Render homepage
app.get('/', async (req, res) => {
    try {
        const feed = await Feedback.find();
        res.render('index', { feed });
    } catch (error) {
        console.error(" Error fetching feedback:", error);
        res.status(500).json({ error: 'Failed to retrieve feedback' });
    }
});

// Handle feedback submission
app.post('/api/feedback', async (req, res) => {

    try {
        const { name, email, message, rating } = req.body;

        // Validate input
        if (!name || !email || !message || !rating) {
            return res.status(400).json({ error: "All fields are required!" });
        }

        // Save to database
        const feedback = new Feedback({ name, email, message, rating });
        await feedback.save();
        res.redirect('/');
    } catch (error) {
        console.error(" Error submitting feedback:", error);
        res.status(500).json({ error: 'Failed to submit feedback' });
    }
});

// Handle feedback update
app.post('/api/feedback/update/:id', async (req, res) => {
    try {
        const { name, email, message, rating } = req.body;
        await Feedback.findByIdAndUpdate(req.params.id, { name, email, message, rating });
        res.redirect('/');
    } catch (error) {
        console.error(" Error updating feedback:", error);
        res.status(500).json({ error: 'Failed to update feedback' });
    }
});

// Handle feedback deletion
app.post('/api/feedback/delete/:id', async (req, res) => {
    try {
        await Feedback.findByIdAndDelete(req.params.id);
        res.redirect('/');
    } catch (error) {
        console.error(" Error deleting feedback:", error);
        res.status(500).json({ error: 'Failed to delete feedback' });
    }
});

// Start server
app.listen(port, () => {
    console.log(` Server running at http://localhost:${port}`);
});
